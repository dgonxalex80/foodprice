# 10-Cargar-librerias.R

# sudo apt-get install coinor-libsymphony-dev
# sudo apt-get install coinor-libsymphony-dev
# install.packages("Rglpk", dependencies = TRUE)
# install.packages("Rsymphony", dependencies = TRUE)
library(tidyverse)
library(lpSolve)
library(Rglpk)
library(Rsymphony)
library(scatterplot3d)
 library(readxl)

